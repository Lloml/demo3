import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)
let json1 = require('../assets/json1')
let json2 = require('../assets/json2')
let json3 = require('../assets/json3')
export default new Vuex.Store({
  state: {
    name: 'json',
    json1: json1,
    json2: json2,
    json3: json3
  },
  mutations: {
    edit (state, payload) {
      state.name = payload
    }
  },
  actions: {},
  modules: {},
  getters: {
    getName: state => {
      return state.name
    },
    getBarFromJson1: state => {
      return state.filter(item => item['cmd'] === 'bar')
    }
  }
}
)
